import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class TextEditor extends JFrame implements ActionListener{
    private String[] style={"Plain", "Bold", "Italic", "Bold and Italic"};
    private String[] size={"12", "16", "18", "20", "22", "24", "26", "28", "30", "32", "34", "38", "40"};
    JButton background, foreground, clearText;
    JComboBox<String> textStyle, textSize;
    JTextArea text;
    JCheckBox checkBorder;
    JScrollPane scroll;
    TextEditor(){
        //System.out.print("\033[H\033[2J");
        System.out.println("Running!!");

        this.setTitle("Text Editor");
        this.setSize(500, 500);
        this.setLocationRelativeTo(null);
        this.setLayout(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        text=new JTextArea();
        text.setBounds(5, 90, 200, 300);
        text.setBackground(new Color(217, 217, 217));
        text.setFont(new Font("Arial", Font.PLAIN, 16));
        text.setLineWrap(true);
        text.setWrapStyleWord(true);

        scroll=new JScrollPane(text);
        scroll.setBounds(5, 90, 477, 300);
        scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        this.add(scroll);

        textStyle = new JComboBox<String>(style);
        textStyle.setBounds(35, 30, 160, 40);
        textStyle.setFont(new Font("Arial", Font.PLAIN, 17));
        textStyle.setFocusable(false);
        textStyle.addActionListener(this);
        this.add(textStyle);

        textSize = new JComboBox<String>(size);
        textSize.setBounds(395, 30, 60, 40);
        textSize.setFont(new Font("Arial", Font.PLAIN, 17));
        textSize.setSelectedIndex(1);
        textSize.setFocusable(false);
        textSize.addActionListener(this);
        this.add(textSize);

        background=new JButton("Background");
        background.setBounds(50, 400, 140, 50);
        background.setBackground(new Color(220, 220, 222));
        background.setFont(new Font("Arial", Font.PLAIN, 18));
        background.setFocusable(false);
        background.addActionListener(this);
        this.add(background);

        clearText=new JButton("Clear");
        clearText.setBounds(200, 400, 100, 50);
        clearText.setFont(background.getFont());
        clearText.setBackground(background.getBackground());
        clearText.setFocusable(false);
        clearText.addActionListener(this);
        this.add(clearText);

        foreground=new JButton("Foreground");
        foreground.setBounds(310, 400, 140, 50);
        foreground.setBackground(new Color(220, 220, 222));
        foreground.setFont(new Font("Arial", Font.PLAIN, 18));
        foreground.setFocusable(false);
        foreground.addActionListener(this);
        this.add(foreground);

        checkBorder=new JCheckBox("Border");
        checkBorder.setBounds(240, 30, 100,40);
        checkBorder.setFont(new Font("Arial", Font.PLAIN, 18));
        checkBorder.setFocusable(false);
        checkBorder.setBackground(background.getBackground());
        checkBorder.setHorizontalAlignment(JCheckBox.CENTER);
        checkBorder.addActionListener(this);
        this.add(checkBorder);

        this.setResizable(false);
        this.setVisible(true);

    }
    public void actionPerformed(ActionEvent e){
        String stl=String.valueOf(textStyle.getSelectedItem()), strsize=String.valueOf(textSize.getSelectedItem());
        int sz=Integer.valueOf(strsize);
        if(e.getSource()==background){
            Color color=JColorChooser.showDialog(null, "Background", text.getBackground());
            text.setBackground(color);
            this.setVisible(true);
        }
        if(e.getSource()==foreground){
            Color color=JColorChooser.showDialog(null, "Foreground", Color.black);
            text.setForeground(color);
            this.setVisible(true);
        }
        if(e.getSource()==textStyle||e.getSource()==textSize){
            stl=String.valueOf(textStyle.getSelectedItem());
            if(stl.equals("Italic"))
                text.setFont(new Font("Arial", Font.ITALIC, sz));
            else if(stl.equals("Bold"))
                text.setFont(new Font("Arial", Font.BOLD, sz));
            else if(stl.equals("Bold and Italic"))
                text.setFont(new Font("Arial", Font.ITALIC+Font.BOLD, sz));
            else
                text.setFont(new Font("Arial", Font.PLAIN, sz));
        }
        if(e.getSource()==checkBorder){
            boolean torf=checkBorder.isSelected();
            if(torf){
                text.setBorder(BorderFactory.createLineBorder(Color.black, 2));
                this.setVisible(true);
            }else{
                text.setBorder(BorderFactory.createLineBorder(Color.black, 0));
                this.setVisible(true);
            }
        }
        if(e.getSource()==clearText){
            text.setText("");
            this.setVisible(true);
        }
    }
}