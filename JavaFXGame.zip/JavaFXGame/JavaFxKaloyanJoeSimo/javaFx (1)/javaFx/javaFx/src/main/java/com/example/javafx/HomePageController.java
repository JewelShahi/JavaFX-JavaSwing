package com.example.javafx;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class HomePageController {
    @FXML
    public Button btnPlay;

    public void btnPlay() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Second Page.fxml"));
        Stage stage = new Stage();
        stage.setScene(new Scene(fxmlLoader.load(), 865, 520));
        stage.setTitle("Let's Play!");
        SecondPageController sc = new SecondPageController();
        sc.setBooleanValues();
        stage.show();
        ((Stage) btnPlay.getScene().getWindow()).close();
    }

}
