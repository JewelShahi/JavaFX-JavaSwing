package com.example.javafx;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class OutOfMoneyController{

    @FXML
    private Button btnHome, btnStartOver, btnExit;


    public void btnExit(){
        Platform.exit();
    }

    public void GoHome() throws IOException{
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Home Page.fxml"));
        Stage stage = new Stage();
        stage.setScene(new Scene(fxmlLoader.load(), 700, 800));
        stage.setTitle("Welcome to your game!");
        stage.show();
        SecondPageController sc = new SecondPageController();
        sc.Balance = 100;
        ((Stage) btnExit.getScene().getWindow()).close();
    }

    public void btnPlayAgain() throws Exception {
        SecondPageController sc = new SecondPageController();
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Second Page.fxml"));
        Stage stage = new Stage();
        stage.setScene(new Scene(fxmlLoader.load(), 865, 520));
        sc.Balance = 100;
        sc.setBooleanValues();
        stage.setTitle("The Game!");
        stage.show();
        ((Stage) btnExit.getScene().getWindow()).close();
    }

}
