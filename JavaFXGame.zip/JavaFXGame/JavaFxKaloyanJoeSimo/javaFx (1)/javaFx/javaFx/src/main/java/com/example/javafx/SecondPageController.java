package com.example.javafx;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;


public class SecondPageController {

    @FXML
    private ImageView Im1;

    @FXML
    private ImageView Im2;

    @FXML
    private ImageView Im3;

    @FXML
    private ImageView Im4;

    @FXML
    private ImageView Im5;

    @FXML
    private ImageView Im6;
    @FXML
    private ImageView Im7;

    @FXML
    private ImageView Im8;

    @FXML
    private ImageView Im9;

    @FXML
    private ImageView Im10;

    @FXML
    private ImageView Im11;

    @FXML
    private ImageView Im12;
    @FXML
    private ImageView Im13;
    @FXML
    private ImageView Im14, ImBlack, ImRed, ImGreen;

    @FXML
    public Button btnBlack, btnRed, btnGreen;


    static Boolean arr[] = new Boolean[17];
    @FXML
    private Label lblBet;

    @FXML
    private Label lblError;

    @FXML
    private Label lblPicker;

    int bet = -1;
    int bets;

    @FXML
    private Button btnPlay;
    public static int Balance = 100;

    @FXML
    public Label lblBalance = new Label(String.valueOf(ThirdPageController.bal));
    @FXML
    public Label lblB;
    @FXML
    public Label lblNz;
    @FXML
    public TextArea txtBalance;


    public void setBooleanValues() {
        for (int i = 0; i < arr.length; i++) {
            this.arr[i] = false;
        }
    }
    public void setVisibleIm(){
        Im1.setVisible(false);
        Im2.setVisible(false);
        Im3.setVisible(false);
        Im4.setVisible(false);
        Im5.setVisible(false);
        Im6.setVisible(false);
        Im7.setVisible(false);
        Im8.setVisible(false);
        Im9.setVisible(false);
        Im10.setVisible(false);
        Im11.setVisible(false);
        Im12.setVisible(false);
        Im13.setVisible(false);
        Im14.setVisible(false);
        ImBlack.setVisible(false);
        ImRed.setVisible(false);
        ImGreen.setVisible(false);

    }

    public boolean checkClickedBtn(){
        boolean flag=false;
        for(int i=0; i<arr.length;i++){
            if(this.arr[i]==true) {
                flag=true;
            }
        }
        return flag;
    }

    public void setPicker1() {

        if(checkClickedBtn()==false){
            Im1.setVisible(true);
            this.arr[0]=true;
        }else{
            Im1.setVisible(false);
            this.arr[0]=false;
        }
    }

    public void setPicker2() {

        if(checkClickedBtn()==false){
            Im2.setVisible(true);
            this.arr[1]=true;
        }else{
            Im2.setVisible(false);
            this.arr[1]=false;
        }
    }
    public void setPicker3() {
        if(checkClickedBtn()==false){
            Im3.setVisible(true);
            this.arr[2]=true;
        }else{
            Im3.setVisible(false);
            this.arr[2]=false;
        }
    }
    public void setPicker4() {
        if(checkClickedBtn()==false){
            Im4.setVisible(true);
            this.arr[3]=true;
        }else{
            Im4.setVisible(false);
            this.arr[3]=false;
        }
    }
    public void setPicker5() {
        if(checkClickedBtn()==false){
            Im5.setVisible(true);
            this.arr[4]=true;
        }else{
            Im5.setVisible(false);
            this.arr[4]=false;
        }
    }
    public void setPicker6() {
        if(checkClickedBtn()==false){
            Im6.setVisible(true);
            this.arr[5]=true;
        }else{
            Im6.setVisible(false);
            this.arr[5]=false;
        }
    }

    public void setPicker7() {
        if(checkClickedBtn()==false){
            Im7.setVisible(true);
            this.arr[6]=true;
        }else{
            Im7.setVisible(false);
            this.arr[6]=false;
        }
    }
    public void setPicker8() {
        if(checkClickedBtn()==false){
            Im8.setVisible(true);
            this.arr[7]=true;
        }else{
            Im8.setVisible(false);
            this.arr[7]=false;
        }
    }

    public void setPicker9() {
        if(checkClickedBtn()==false){
            Im9.setVisible(true);
            this.arr[8]=true;
        }else{
            Im9.setVisible(false);
            this.arr[8]=false;
        }
    }
    public void setPicker10() {
        if(checkClickedBtn()==false){
            Im10.setVisible(true);
            this.arr[9]=true;
        }else{
            Im10.setVisible(false);
            this.arr[9]=false;
        }
    }

    public void setPicker11() {
        if(checkClickedBtn()==false){
            Im11.setVisible(true);
            this.arr[10]=true;
        }else{
            Im11.setVisible(false);
            this.arr[10]=false;
        }
    }
    public void setPicker12() {
        if(checkClickedBtn()==false){
            Im12.setVisible(true);
            this.arr[11]=true;
        }else{
            Im12.setVisible(false);
            this.arr[11]=false;
        }
    }

    public void setPicker13() {
        if(checkClickedBtn()==false){
            Im13.setVisible(true);
            this.arr[12]=true;
        }else{
            Im13.setVisible(false);
            this.arr[12]=false;
        }
    }
    public void setPicker0() {
        if(checkClickedBtn()==false){
            Im14.setVisible(true);
            this.arr[13]=true;
        }else{
            Im14.setVisible(false);
            this.arr[13]=false;
        }
    }

    public void setPickerBlack() {
        if(checkClickedBtn()==false){
            ImBlack.setVisible(true);
            this.arr[14]=true;
        }else{
            ImBlack.setVisible(false);
            this.arr[14]=false;
        }
    }

    public void setPickerRed() {
        if(checkClickedBtn()==false){
            ImRed.setVisible(true);
            this.arr[15]=true;
        }else{
            ImRed.setVisible(false);
            this.arr[15]=false;
        }
    }

    public void setPickerGreen() {
        if(checkClickedBtn()==false){
            ImGreen.setVisible(true);
            this.arr[16]=true;
        }else{
            ImGreen.setVisible(false);
            this.arr[16]=false;
        }
    }

    @FXML
    public TextField lblBett;
    @FXML
    public Button btn2lv, btn5lv, btn10lv;

    public boolean checkNegativeBalance(Integer balance, int add, int money){
       if((balance+add)<=money)
           return true;
       else
           return false;
    }

    public boolean checkPositiveBalance(Integer balance, int remove){
        if((balance-remove)>0)
            return true;
        else
            return false;
    }

    public void AllIn(){
        bets = Balance;
        lblBett.setText(Integer.toString(bets));
    }

    public void addMoney2() {
        bets = Integer.parseInt(lblBett.getText());
        System.out.println(bets);
        if (checkNegativeBalance(Integer.parseInt(lblBett.getText()), 2, Balance)) {
            bets +=2;
            lblBett.setText(Integer.toString(bets));
        } else {
            lblError.setText("Not enough money!");
            lblError.setVisible(true);
        }
    }
    public void addMoney5() {
        bets = Integer.parseInt(lblBett.getText());
        System.out.println(bets);
        if (checkNegativeBalance(Integer.parseInt(lblBett.getText()), 5, Balance)) {
            bets += 5;
            lblBett.setText(Integer.toString(bets));
        } else {
            lblError.setText("Not enough money!");
            lblError.setVisible(true);
    }
    }
    public void addMoney10() {
        bets = Integer.parseInt(lblBett.getText());
        System.out.println(bets);
        if (checkNegativeBalance(Integer.parseInt(lblBett.getText()), 10, Balance)) {
            bets += 10;
            lblBett.setText(Integer.toString(bets));
        } else {
            lblError.setText("Not enough money!");
            lblError.setVisible(true);
        }
    }

    public void removeMoney1() {
        bets = Integer.parseInt(lblBett.getText());
        System.out.println(bets);
        if (checkPositiveBalance(Integer.parseInt(lblBett.getText()), 1)) {
            bets-=1;
            lblBett.setText(Integer.toString(bets));
        } else {
            lblError.setText("Your bet NOW is minimum!");
            lblError.setVisible(true);
        }
    }
    public void removeMoney2() {
        bets = Integer.parseInt(lblBett.getText());
        System.out.println(bets);
        if (checkPositiveBalance(Integer.parseInt(lblBett.getText()), 2)) {
            bets -= 2;
            lblBett.setText(Integer.toString(bets));
        } else {
            lblError.setText("Your bet NOW is minimum!");
            lblError.setVisible(true);
        }
    }

    public void removeMoney5() {
        bets = Integer.parseInt(lblBett.getText());
        System.out.println(bets);
        if (checkPositiveBalance(Integer.parseInt(lblBett.getText()), 5)) {
            bets -= 5;
            System.out.println(bets);
            lblBett.setText(Integer.toString(bets));
        } else {
            lblError.setText("Your bet NOW is minimum!");
            lblError.setVisible(true);
        }
    }



    public void setBtnPlay() throws Exception{
        ((Stage) lblBett.getScene().getWindow()).hide();
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Third Page.fxml"));
            Stage stage = new Stage();
            stage.setScene(new Scene(fxmlLoader.load(), 900, 540));
            stage.setTitle("GOOD LUCK!");
            stage.setResizable(false);
            ThirdPageController tr = fxmlLoader.getController();
            tr.setBal(this.Balance);
            tr.getStage((Stage) lblBalance.getScene().getWindow());

            if(checkClickedBtn()==false){
                lblError.setText("Please select your bet num!");
                lblError.setVisible(true);
            }else{
                lblError.setText("Please select your bet num!");
                lblError.setVisible(false);
                for(int i=0;i<arr.length;i++)
                    if(arr[i]==true)
                        bet=i+1;
                if(bet>=15) {
                    switch(bet) {
                        case 15: tr.setText("Black"); break;
                        case 16: tr.setText("Red"); break;
                        case 17: tr.setText("Green"); break;
                    }
                }else {
                    tr.setText(Integer.toString(bet));
                }
                stage.show();
//                ((Stage) (lblPicker.getScene().getWindow())).close();

                lblBalance.setText( String.valueOf(tr.winningNum(bet, bets, Balance))); //bets са заложените пари
                }
            setBooleanValues();
            setVisibleIm();
        bets = 1;
        lblBett.setText(Integer.toString(bets));
            }

    public void setLblBalance(Label lblBalance) {
        this.lblBalance = lblBalance;
    }
}
