package com.example.javafx;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class FirstPageController extends SecondPageController{
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() throws Exception {
        SecondPageController sc = new SecondPageController();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Second Page.fxml"));
        Stage stage = new Stage();
        stage.setScene(new Scene(fxmlLoader.load(), 1000, 600));
        stage.setTitle("Second Page!");
        sc.setBooleanValues();
        stage.show();
        ((Stage) welcomeText.getScene().getWindow()).close();
    }
}