package com.example.javafx;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Background;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Random;

public class ThirdPageController{

    @FXML
    private Button btnExit;

    @FXML
    private Button btnPlayAgain;

    @FXML
    private Label lblMyNum;

    @FXML
    private Label lblWinNum;

    @FXML
    private Label lblWinLose, lblSetBalance;



    public void setText(String stt) {
        lblMyNum.setTextFill(Color.WHITE);
        if (stt.equals("Black")) {
            lblMyNum.setBackground(Background.fill(Color.BLACK));
        }else{
            if (stt.equals("Red"))
                lblMyNum.setBackground(Background.fill(Color.RED));
            else if (stt.equals("Green"))
                lblMyNum.setBackground(Background.fill(Color.GREEN));
            else {

                if (Double.parseDouble(stt) == 14) {
                    lblMyNum.setText("0");
                    lblMyNum.setBackground(Background.fill(Color.GREEN));
                } else {
                    lblMyNum.setText(stt);
                    int st = Integer.parseInt(stt);
                    if (st % 2 == 0) {
                        lblMyNum.setBackground(Background.fill(Color.BLACK));
                    } else
                        lblMyNum.setBackground(Background.fill(Color.RED));
                }
            }
        }
    }

    public static int bal;

    public void setBal(int val) {
        this.bal = val;
        this.lblSetBalance.setText(Double.toString(bal));
    }


    public Stage st;
    public void getStage(Stage stt){
        this.st = stt;
    }

    public void GoHome() throws IOException{
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Home Page.fxml"));
        Stage stage = new Stage();
        stage.setScene(new Scene(fxmlLoader.load(), 700, 800));
        stage.setTitle("Welcome to your game!");
        stage.show();
        SecondPageController sc = new SecondPageController();
        sc.Balance = 100;
        st.close(); //close the other window!
        ((Stage) lblMyNum.getScene().getWindow()).close();
    }



    public void PlayAgainBtn()  throws IOException {
        if(Double.parseDouble(lblSetBalance.getText()) > 0) {
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Second Page.fxml"));
            SecondPageController sc = new SecondPageController();
            sc.setBooleanValues();
            sc.Balance = bal;
            sc.lblBalance.setText(String.valueOf(sc.Balance));
            st.show();
        }else
        {
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("OutOfMoney.fxml"));
            Stage stage = new Stage();
            stage.setScene(new Scene(fxmlLoader.load(), 951, 770));
            stage.setTitle("Out Of Money!");
            stage.show();
            st.close();
        }
        ((Stage) lblWinLose.getScene().getWindow()).close();
    }
    public void ExitBtn() {
        Platform.exit();
    }

    public double winningNum(Integer betNum, int betMoney, int balance) {
        Random random = new Random();
        int winNum =0;
        winNum = random.nextInt(14);
        lblWinNum.setTextFill(Color.WHITE);
        String color="";
        if(winNum<=14) {
                lblWinNum.setText(Integer.toString(winNum));
            if(winNum==0 || winNum==14) {
                lblWinNum.setBackground(Background.fill(Color.GREEN));
                color = "Green";
            }else{
            if(winNum%2==0) {
                lblWinNum.setBackground(Background.fill(Color.BLACK));
                color = "Black";
            }else {
                lblWinNum.setBackground(Background.fill(Color.RED));
                color="Red";
            }
            }
        }

        SecondPageController sc = new SecondPageController();
        sc.setBooleanValues();

        if(betNum>=15) {
            if ((betNum == 15 && color.equals("Black")) || (betNum == 16 && color.equals("Red")) || (betNum == 17 && color.equals("Green"))) {
                lblWinLose.setText("Congrats! You won " + (betMoney * 2) + "!");
                lblWinLose.setTextFill(Color.GREEN);
                sc.Balance+=betMoney*2;
                setBal(sc.Balance);
            } else {
                lblWinLose.setText("Sorry! You lost " + betMoney + "!");
                lblWinLose.setTextFill(Color.RED);
                sc.Balance-=betMoney;
                setBal(sc.Balance);
            }
        }else {
            if (betNum == winNum) {
                lblWinLose.setText("Congrats! You won " + (betMoney*2) + "!");
                lblWinLose.setTextFill(Color.GREEN);
                sc.Balance+=betMoney*2;
                setBal(sc.Balance);
                lblWinLose.setTextFill(Color.GREEN);
            } else {
                lblWinLose.setText("Sorry! You lost " + betMoney + "!");
                lblWinLose.setTextFill(Color.RED);
                sc.Balance-=betMoney;
                setBal(sc.Balance);
                lblWinLose.setTextFill(Color.RED);
            }
        }
        lblWinLose.setVisible(true);
        return sc.Balance;
    }
}